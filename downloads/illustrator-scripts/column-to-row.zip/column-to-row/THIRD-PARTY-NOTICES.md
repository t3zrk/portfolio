THIRD-PARTY NOTICES

No third-party source code or dependencies were identified within this user-supplied script during static review. This is not proof of original authorship or exclusive ownership; please confirm rights before publishing. The Adobe Illustrator application and ExtendScript APIs are provided by Adobe and are not included.
