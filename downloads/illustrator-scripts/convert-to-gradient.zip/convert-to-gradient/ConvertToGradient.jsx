/*
 * Convert to Gradient — Adobe Illustrator ExtendScript
 * Package curator / maintainer: t3zrk
 * Contains upstream third-party material; original author attribution and licensing are in THIRD-PARTY-NOTICES.md.
 * SPDX-License-Identifier: MIT
 * Review build: test on a copy of your artwork before production use.
 */
/* This upload appears to adapt ConvertToGradient from the creold Illustrator scripts collection.
 * Upstream: https://github.com/creold/illustrator-scripts
 * Upstream collection: MIT License; copyright and source attribution preserved.
 * Local changes/packaging by t3zrk, 2026. Ownership of upstream code is NOT claimed.
 */
//@target illustrator

var fillBad = 0;
var originalStates = []; // Store original states for preview

function main() {
  var SCRIPT = {
        name: 'ConvertToGradient',
        version: 'v0.2.0'
      },
      CFG = {
        aiVers: parseFloat(app.version),
        isMac: /mac/i.test($.os),
        uiOpacity: .97 // UI window opacity. Range 0-1
      };

  if (!documents.length) {
    alert('Error\nOpen a document and try again');
    return;
  }

  if (!selection.length || selection.typename == 'TextRange') {
    alert('Error\nPlease select at least one object');
    return;
  }

  var doc = app.activeDocument,
      maxValue = isRgbDoc() ? 255 : 100,
      shiftValue = 10,
      angleValue = 0,
      contrastValue = 10;

  // Save original states for preview
  saveOriginalStates(selection);

  // Main Window
  var dialog = new Window('dialog', SCRIPT.name + ' ' + SCRIPT.version);
      dialog.preferredSize.width = 250;
      dialog.orientation = 'column';
      dialog.alignChildren = ['fill', 'fill'];
      dialog.opacity = CFG.uiOpacity;

  // Gradient Shift Slider
  var shiftPanel = dialog.add('panel', undefined, 'Gradient Shift');
      shiftPanel.alignChildren = ['fill', 'center'];
  var shiftGroup = shiftPanel.add('group');
      shiftGroup.orientation = 'row';
  var shiftSlider = shiftGroup.add('slider', undefined, shiftValue, 0, maxValue);
  var shiftValueText = shiftGroup.add('edittext', undefined, shiftValue.toString());
      shiftValueText.characters = 4;

  shiftSlider.onChanging = function () {
    shiftValue = Math.round(shiftSlider.value);
    shiftValueText.text = shiftValue.toString();
  };

  shiftValueText.onChange = function () {
    var value = Math.min(Math.max(0, parseInt(shiftValueText.text) || 0), maxValue);
    shiftSlider.value = value;
    shiftValueText.text = value.toString();
    shiftValue = value;
  };

  // Gradient Angle Slider
  var anglePanel = dialog.add('panel', undefined, 'Gradient Angle');
      anglePanel.alignChildren = ['fill', 'center'];
  var angleGroup = anglePanel.add('group');
      angleGroup.orientation = 'row';
  var angleSlider = angleGroup.add('slider', undefined, angleValue, -180, 180);
  var angleValueText = angleGroup.add('edittext', undefined, angleValue.toString());
      angleValueText.characters = 4;

  angleSlider.onChanging = function () {
    angleValue = Math.round(angleSlider.value);
    angleValueText.text = angleValue.toString();
  };

  angleValueText.onChange = function () {
    var value = Math.min(Math.max(-180, parseInt(angleValueText.text) || 0), 180);
    angleSlider.value = value;
    angleValueText.text = value.toString();
    angleValue = value;
  };

  // Color Contrast Slider
  var contrastPanel = dialog.add('panel', undefined, 'Color Contrast');
      contrastPanel.alignChildren = ['fill', 'center'];
  var contrastGroup = contrastPanel.add('group');
      contrastGroup.orientation = 'row';
  var contrastSlider = contrastGroup.add('slider', undefined, contrastValue, 0, maxValue);
  var contrastValueText = contrastGroup.add('edittext', undefined, contrastValue.toString());
      contrastValueText.characters = 4;

  contrastSlider.onChanging = function () {
    contrastValue = Math.round(contrastSlider.value);
    contrastValueText.text = contrastValue.toString();
  };

  contrastValueText.onChange = function () {
    var value = Math.min(Math.max(0, parseInt(contrastValueText.text) || 0), maxValue);
    contrastSlider.value = value;
    contrastValueText.text = value.toString();
    contrastValue = value;
  };

  // Buttons
  var btns = dialog.add('group');
      btns.alignChildren = ['fill', 'fill'];
      btns.orientation = 'column';
  var cancel = btns.add('button', undefined, 'Cancel', { name: 'cancel' });
      cancel.helpTip = 'Press Esc to Close';
  var ok = btns.add('button', undefined, 'OK', { name: 'ok' });
      ok.helpTip = 'Press Enter to Run';

  ok.onClick = function () {
    applyChanges(shiftValue, angleValue, contrastValue, maxValue);
    dialog.close();
  };

  cancel.onClick = function () {
    revertToOriginalStates(selection);
    dialog.close();
  };

  dialog.center();
  dialog.show();
}

function saveOriginalStates(selection) {
  originalStates = [];
  for (var i = 0; i < selection.length; i++) {
    var item = selection[i];
    originalStates.push({
      item: item,
      fillColor: item.fillColor
    });
  }
}

function revertToOriginalStates(selection) {
  for (var i = 0; i < originalStates.length; i++) {
    var state = originalStates[i];
    state.item.fillColor = state.fillColor;
  }
}

function applyChanges(shift, angle, contrast, maxValue) {
  var channel = isRgbDoc() ? ['red', 'green', 'blue'] : ['cyan', 'magenta', 'yellow', 'black'];
  for (var i = 0, selLen = selection.length; i < selLen; i++) {
    try {
      convertToGradient(selection[i], shift, angle, contrast, channel, maxValue, maxValue - shift);
    } catch (e) {
      $.writeln('Skipped object: ' + e.message);
    }
  }
  if (fillBad > 0) {
    $.writeln('Skipped ' + fillBad + ' objects due to unsupported fills.');
  }
}

function convertToGradient(obj, shift, angle, contrast, channel, max, shiftEnd) {
  switch (obj.typename) {
    case 'GroupItem':
      for (var j = 0, piLen = obj.pageItems.length; j < piLen; j++) {
        convertToGradient(obj.pageItems[j], shift, angle, contrast, channel, max, shiftEnd);
      }
      break;
    case 'PathItem':
      if (obj.filled && chkFillType(obj)) {
        applyGradient(obj, shift, angle, contrast, max, shiftEnd, channel);
      } else {
        fillBad++;
      }
      break;
    case 'CompoundPathItem':
      if (obj.pathItems[0].filled && chkFillType(obj.pathItems[0])) {
        applyGradient(obj.pathItems[0], shift, angle, contrast, max, shiftEnd, channel);
      } else {
        fillBad++;
      }
      break;
    default:
      fillBad++;
      break;
  }
}

function applyGradient(obj, shift, angle, contrast, max, shiftEnd, channel) {
  var currentColor = (obj.fillColor.typename == 'SpotColor') ? obj.fillColor.spot.color : obj.fillColor;
  var startColor = isRgbDoc() ? new RGBColor() : new CMYKColor();
  var endColor = isRgbDoc() ? new RGBColor() : new CMYKColor();

  if (currentColor.typename == 'GrayColor') {
    var startColor = new GrayColor();
    var endColor = new GrayColor();
    var grayColor = Math.round(currentColor.gray);

    startColor.gray = Math.max(0, grayColor - shift - contrast);
    endColor.gray = Math.min(100, grayColor + shift + contrast);
  }

  for (var j = 0, len = channel.length; j < len; j++) {
    var channelName = channel[j];
    var originColor = Math.round(currentColor[channelName]);

    startColor[channelName] = Math.max(0, originColor - shift - contrast);
    endColor[channelName] = Math.min(max, originColor + shift + contrast);
  }

  var newGradient = activeDocument.gradients.add();
  newGradient.type = GradientType.LINEAR;

  newGradient.gradientStops[0].rampPoint = 0;
  newGradient.gradientStops[0].midPoint = 50;
  newGradient.gradientStops[0].color = startColor;

  newGradient.gradientStops[1].rampPoint = 100;
  newGradient.gradientStops[1].color = endColor;

  var colorOfGradient = new GradientColor();
  colorOfGradient.gradient = newGradient;

  obj.fillColor = colorOfGradient;
  obj.rotate(angle, false, false, true, false, Transformation.CENTER);
}

function isRgbDoc() {
  return activeDocument.documentColorSpace == DocumentColorSpace.RGB;
}

function chkFillType(obj) {
  return obj.fillColor.typename == 'RGBColor' ||
         obj.fillColor.typename == 'CMYKColor' ||
         obj.fillColor.typename == 'GrayColor' ||
         obj.fillColor.typename == 'SpotColor';
}

// Run script 
try {
  main();
} catch (e) {
  alert('An error occurred: ' + e.message);
}
