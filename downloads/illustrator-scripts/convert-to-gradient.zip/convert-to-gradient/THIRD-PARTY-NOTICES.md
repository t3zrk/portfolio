THIRD-PARTY NOTICES — Convert to Gradient

This code appears related to the ConvertToGradient script in Sergey Osokin's MIT-licensed Illustrator scripts collection: https://github.com/creold/illustrator-scripts
Its precise modification lineage could not be established from the uploaded ZIP. Original third-party ownership is not assigned to t3zrk. The upstream project and license are credited here, and the code is presented as a curated/adapted utility, not exclusive original work. Confirm the origin of any other modifications before publishing.
