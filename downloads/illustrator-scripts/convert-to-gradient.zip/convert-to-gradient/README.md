# Convert to Gradient

**Curated/packaged by:** t3zrk  
**Origin:** Third-party-based script; see THIRD-PARTY-NOTICES.md  
**For:** Adobe Illustrator desktop, JavaScript / ExtendScript (`.jsx`). This is not a Photoshop, Figma or browser plugin.

## What it does

Select filled vector shapes and adjust colour shift, contrast and gradient angle before applying a linear gradient. The script processes supported RGB, CMYK, grayscale and spot-colour fills, skipping unsupported items. Make a copy of the artwork first; complex fills and document colour spaces need manual review.

## Design workflow benefit

Turn a batch of flat-colour assets into gradient explorations without rebuilding each gradient individually. No quantified time savings have been measured.

## Install and run

1. Unzip the package; open the `.jsx` file in a text editor if you wish to inspect it.
2. In Illustrator, open a document and select the relevant text frames or objects.
3. Run **File → Scripts → Other Script...**, then choose `ConvertToGradient.jsx`. Alternatively place the script in Illustrator's language-specific `Presets/.../Scripts` folder and restart Illustrator.
4. Try it first on a duplicate of your artwork. The included `.svg` is an icon asset, not a separate installer or an Illustrator toolbar button.

## Conditions and limitations

- No network access, analytics, account login, or AI API is required by this release.
- These scripts may change live text/fills in the active document; undo or duplicate the file before running.
- Only static code review and JavaScript syntax checks were possible here; Illustrator runtime compatibility, colour fidelity and typography retention were **not** verified in Illustrator.
- License: see `LICENSE`; see `THIRD-PARTY-NOTICES.md` for source provenance.
