# Batch Text Replace

**Curated/packaged by:** t3zrk  
**Origin:** User-provided original script (verify ownership before publication)  
**For:** Adobe Illustrator desktop, JavaScript / ExtendScript (`.jsx`). This is not a Photoshop, Figma or browser plugin.

## What it does

Enter the original and replacement text for up to five pairs, choose whether to ignore letter case, and apply the changes across selected Illustrator text frames. Useful for updating campaign terms, product labels, disclaimers or repeated copy in a set of variants. Replacements are literal and whole-word/phrase-based; save a copy when text styling is important.

## Design workflow benefit

One dialog can replace many repetitive manual edits across a campaign layout. No quantified time savings have been measured.

## Install and run

1. Unzip the package; open the `.jsx` file in a text editor if you wish to inspect it.
2. In Illustrator, open a document and select the relevant text frames or objects.
3. Run **File → Scripts → Other Script...**, then choose `Text Replace.jsx`. Alternatively place the script in Illustrator's language-specific `Presets/.../Scripts` folder and restart Illustrator.
4. Try it first on a duplicate of your artwork. The included `.svg` is an icon asset, not a separate installer or an Illustrator toolbar button.

## Conditions and limitations

- No network access, analytics, account login, or AI API is required by this release.
- These scripts may change live text/fills in the active document; undo or duplicate the file before running.
- Only static code review and JavaScript syntax checks were possible here; Illustrator runtime compatibility, colour fidelity and typography retention were **not** verified in Illustrator.
- License: see `LICENSE`; see `THIRD-PARTY-NOTICES.md` for source provenance.
