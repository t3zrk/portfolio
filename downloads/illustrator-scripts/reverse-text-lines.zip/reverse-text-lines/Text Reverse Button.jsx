/*
 * Reverse Text Lines — Adobe Illustrator ExtendScript
 * Package curator / maintainer: t3zrk
 * Creator: t3zrk (user-provided original script).
 * SPDX-License-Identifier: MIT
 * Review build: test on a copy of your artwork before production use.
 */
//@target illustrator
// Check if there is an active document
if (app.documents.length > 0) {
  // Get the active document
  var doc = app.activeDocument;

  // Check if there is a selection
  if (doc.selection.length === 1) {
    // Get the selected text
    var selectedText = doc.selection[0];

    // Check if the selected item is a text frame
    if (selectedText.typename === "TextFrame") {
      // Get the content of the text frame
      var originalText = selectedText.contents;

      // Split the text into paragraphs
      var paragraphs = originalText.split("\r");

      // Reverse the order of paragraphs
      var reversedParagraphs = paragraphs.reverse();

      // Join the reversed paragraphs
      var reversedText = reversedParagraphs.join("\r");

      // Set the content of the text frame to the reversed text
      selectedText.contents = reversedText;
    } else {
      alert("Please select a text frame.");
    }
  } else {
    alert("Please select exactly one text frame.");
  }
} else {
  alert("No active document found.");
}
