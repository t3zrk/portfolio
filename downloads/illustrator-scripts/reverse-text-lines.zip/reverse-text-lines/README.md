# Reverse Text Lines

**Curated/packaged by:** t3zrk  
**Origin:** User-provided original script (verify ownership before publication)  
**For:** Adobe Illustrator desktop, JavaScript / ExtendScript (`.jsx`). This is not a Photoshop, Figma or browser plugin.

## What it does

Choose one text frame containing several line-separated items and run the script. It reverses their order while leaving the wording of each item unchanged. Useful for flipping a ranking, date list, storyboard outline or product sequence. This reverses lines, not character direction or text on a path.

## Design workflow benefit

Reorder lengthy lists in one action instead of copying lines one by one. No quantified time savings have been measured.

## Install and run

1. Unzip the package; open the `.jsx` file in a text editor if you wish to inspect it.
2. In Illustrator, open a document and select the relevant text frames or objects.
3. Run **File → Scripts → Other Script...**, then choose `Text Reverse Button.jsx`. Alternatively place the script in Illustrator's language-specific `Presets/.../Scripts` folder and restart Illustrator.
4. Try it first on a duplicate of your artwork. The included `.svg` is an icon asset, not a separate installer or an Illustrator toolbar button.

## Conditions and limitations

- No network access, analytics, account login, or AI API is required by this release.
- These scripts may change live text/fills in the active document; undo or duplicate the file before running.
- Only static code review and JavaScript syntax checks were possible here; Illustrator runtime compatibility, colour fidelity and typography retention were **not** verified in Illustrator.
- License: see `LICENSE`; see `THIRD-PARTY-NOTICES.md` for source provenance.
