THIRD-PARTY NOTICES — Contrast Checker

Original author: Sergey Osokin.
Original project: https://github.com/creold/illustrator-scripts/blob/master/jsx/ContrastChecker.jsx
Original release: v0.1.1 (MIT). The supplied script matches that upstream source with the attribution header removed. This package restores attribution and the applicable MIT license; t3zrk is listed only as package curator/maintainer, not as exclusive creator.
